<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pushnote extends CI_Controller {

public function index()
{
   $this->load->view('pushdemo');
}

public function send_push_notification()
{
    $arr[]=$this->input->post('token');
    $url='https://fcm.googleapis.com/fcm/send';
     
      /*api_key available in:
    Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/   
    //change api key with your api key
    $api_key='_AAAAiXXXPNY:APA91bGdv6Z6hf8HyWf__8RqkxyTsm60U__VVFISUKvztWXPcgFxZYZ2JJIibZF1KCD44d1Dke3SpVZwJCENfOOv0VESpds2hDSZnpYeZZUmCn4Kr5HYfNl5XNfoxWGRyZ75t5uAeCnzBS';

    $fields=array(
      'registration_ids'=>$arr,
      'data'=>array(
         "title"=>"push note demo new",
         "body"=>"body of push note new"
      )
    );

    $headers=array(
       'Content-Type:application/json',
       'Authorization:key='.$api_key
    );

     $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    $result = curl_exec($ch);
    if ($result === FALSE) {
        die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);

}


}
	?>
