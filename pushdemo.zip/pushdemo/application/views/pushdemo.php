<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<h1 style="text-align:center;">Push Notification Tutorial</h1>
</body>
</html>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js"></script>
<script type="text/javascript">
 // Your web app's Firebase configuration
 //change configuration with your configuration
const firebaseConfig = {
  apiKey: "AIzaSyA5acC1z0BSrHEuQEujMrWG94BeNGIekFQ",
  authDomain: "pushnote-9eree05a.firebaseapp.com",
  projectId: "pushnote-9ere05a",
  storageBucket: "pushnote-9edf05a.appspot.com",
  messagingSenderId: "590387559638",
  appId: "1:590387559638:web:67f5c6f6fd48df42c96e5d77",
  measurementId: "G-FGS4X92CFY"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

//this is key pair get from  Firebase Console -> Project Settings -> CLOUD MESSAGING -> key Pair*/
//change keypair with your keypair 
messaging.getToken({ vapidKey: 'BHxUzo7d0FmjL--9CaY7g00b6IQEWp0i9a-byFVxkto3oVPNfusL5krgZlfaJ_nGbK8lb0t8Ht1zskLmTWCu4LrY__' }).then((currentToken) => {
  if (currentToken) {
      
      $.ajax({
          url:'<?= base_url('Pushnote/send_push_notification');?>',
          data:{token:currentToken},
          type:"post",
          success:function(data)
          {

          }

      })

  } else {
    // Show permission request UI
    console.log('No registration token available. Request permission to generate one.');
    // ...
  }
}).catch((err) => {
  console.log('An error occurred while retrieving token. ', err);
  // ...
});


messaging.onMessage((data)=>{
	Notification.requestPermission((status)=>{
     
     if(status=='granted')
     {
     	 let title=data['data']['title'];
     	 let body=data['data']['body'];
     	 new Notification(title,{
     	 	 body:body
     	 })
     }
	})
})


</script>